$(document).ready(function() {
    setTimeout(function() {
        $(".sesion").fadeOut(1500);
    },2000);
});
